 /******************************************************************************
 *
 * Module: CONTROL MCU (main)
 *
 * File Name: main.H
 *
 * Description: Header file for the CONTROL-MCU driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/

#ifndef MCU2_H_
#define MCU2_H_

#include "gpio.h"
#include "twi.h"
#include "dc_motor.h"
#include "buzzer.h"
#include "std_types.h"
#include "common_macros.h"
#include "timer.h"
#include "uart.h"
#include "external_eeprom.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/


#define FAIL 0x11
#define PASS 0x12

#define UART_BAUDRATE 9600
#define PASS_LENGTH 7
#define PASS_ADDRESS 0x0311
#define MAX_TRIES 3

#define MATCHING 0x31
#define NOT_MATCHING 0x32

#define READY_TO_RECIEVE 9

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*	Function description:
 *
 * 	Function that compares the stored password in the EEPROM with the entered one
 *
 * 	result is either PASS or FAIL which are send by the uart_sendByte
 *
 * */

void ComparePassword(void);


/*	Function description:
 *
 * 	Function that stores the password either entered for the first time or after
 * 	choosing to change the password
 *
 * */

void StoreRecievedPassword(void);

/*	Function description:
 *
 * 	It is the call back function of the timer
 *
 * 	contains a counter that increments every timer interrupt
 *
 * */

void TIMER0_counter(void);

#endif /* MCU2_H_ */
