 /******************************************************************************
 *
 * Module: TIMER
 *
 * File Name: Timer.C
 *
 * Description: Source file for the Timer driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/

#include "timer.h"
#include <avr/interrupt.h>
/*******************************************************************************
 * 								GLOBAL VARIABLES							   *
 *******************************************************************************/

uint8 CURRENT_CLK=0;

static void (*Timer0_callback)(void) = NULL_PTR;
static void (*Timer1_callback)(void) = NULL_PTR;
static void (*Timer2_callback)(void) = NULL_PTR;

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/


/*******************************************************************************
 *
 *ISR's of Timers 0,1,2
 *
 *Used to set the callback functions.
 *
 *******************************************************************************/

ISR (TIMER0_OVF_vect) {

	if (Timer0_callback != NULL_PTR) {
		(*Timer0_callback)();
	}
}

ISR (TIMER0_COMP_vect) {
	if (Timer0_callback != NULL_PTR) {
		(*Timer0_callback)();
	}
}

ISR (TIMER1_OVF_vect) {
	if (Timer1_callback != NULL_PTR) {
		(*Timer1_callback)();
	}
}

ISR (TIMER1_COMPA_vect) {
	if (Timer1_callback != NULL_PTR) {
		(*Timer1_callback)();
	}
}

ISR (TIMER2_OVF_vect) {
	if (Timer2_callback != NULL_PTR) {
		(*Timer2_callback)();
	}
}

ISR (TIMER2_COMP_vect) {
	if (Timer2_callback != NULL_PTR) {
		(*Timer2_callback)();
	}
}

/*****************************************************************************
 * Function description: Function that initialize the timer module
 *
 *
 * Input: Structure that contains the static configurations :-
 * 		  1- Prescalar
 *		  2- Timer ID (0,1,2)
 *		  3- OVERFLOW & COMPARE
 *		  4- Compare value (if needed)
 *
 * return: void
 ****************************************************************************/

void Timer_init(const Timer_ConfigType *Configurations) {
	/*	Store the chosen prescalar in global variable to be reused during the resume function	*/

	CURRENT_CLK=(Configurations->clock);

	/*	Insert bits depending on the chosen Timer	*/

	switch (Configurations->ID) {

		case TIMER0:

		/*	Set The clock for timer 0	*/
		TCCR0 = (Configurations->clock)|(1<<FOC0);

		/*	Set the mode of the timer : Overflow or Compare	*/
		TCCR0 |= ((Configurations->mode) << WGM01)|(0<<WGM00);

		if (Configurations->mode == COMPARE) {
			TIMSK |= (1 << OCIE0);

			OCR0 = (Configurations->Compare_value);
		} else if (Configurations->mode == OVERFLOW) {
			TIMSK|= (1 << TOIE0);

		}

		TCNT0 = 0;

		break;

		case TIMER1:

		/*	Set The clock for timer 1	*/
		TCCR1B = (Configurations->clock)|((Configurations->mode) << WGM12) ;

		/*	Set the mode of the timer : Overflow or Compare	*/
		if (Configurations->mode == COMPARE) {
			TIMSK |= (1 << OCIE1A);

			OCR1A = (Configurations->Compare_value);
		} else if (Configurations->mode == OVERFLOW) {
			TIMSK |= (1 << TOIE1);
		}

		TCNT1 = 0;
		break;

	case TIMER2:

		/*	Set The clock for timer 2	*/
		TCCR2 = (Configurations->clock);

		/*	Set the mode of the timer : Overflow or Compare	*/
		TCCR2 |= ((Configurations->mode) << WGM21)|(1<<FOC2);

		if (Configurations->mode == COMPARE) {
			TIMSK |= (1 << OCIE2);

			OCR2 = (Configurations->Compare_value);
		} else if (Configurations->mode == OVERFLOW) {
			TIMSK |= (1 << TOIE2);
		}

		TCNT2 = 0;
		break;

	}
}

/*****************************************************************************
 * Function description: Function that Set the callback function the timer module
 * 						 to be executed when an interrupt occurs
 *
 *
 * Input: A)	Pointer to a function that is required to be executed when the ISR
 * 				occurs
 *		  B)    Timer ID
 *
 * return: void
 ****************************************************************************/

void Timer_setCallBack(void (*a_ptr)(void), TIMER_ID ID) {
	switch (ID) {
	case TIMER0:

		Timer0_callback = a_ptr;

		break;

	case TIMER1:

		Timer1_callback = a_ptr;

		break;

	case TIMER2:

		Timer2_callback = a_ptr;

		break;

	}
}

/*****************************************************************************
 * Function description: Function that pauses the timer of the selected timer
 *
 *
 * Input: Timer ID of the required number (Timer ID)
 *
 *
 * return: void
 ****************************************************************************/

void Timer_pause(TIMER_ID ID) {

	switch (ID) {
	case TIMER0:

		TCCR0 = (TCCR0 & 0xF8);

		break;

	case TIMER1:

		TCCR1B = (TCCR1B & 0xF8);
		break;

	case TIMER2:

		TCCR2 = (TCCR2 & 0xF8);
		break;

	}
}

/*****************************************************************************
 * Function description: Function that resumes the timer of the selected timer
 *
 *
 * Input: Timer ID of the required number (Timer ID)
 *
 *
 * return: void
 ****************************************************************************/

void Timer_resume(TIMER_ID ID) {

	switch (ID) {
	case TIMER0:
		TCCR0 |= CURRENT_CLK;
		break;

	case TIMER1:
		TCCR1B |= CURRENT_CLK;
		break;

	case TIMER2:
		TCCR2 |= CURRENT_CLK;
		break;

	}
}

/*****************************************************************************
 * Function description: Function that resets the timer of the selected timer
 *
 *
 * Input: Timer ID of the required number (Timer ID)
 *
 *
 * return: void
 ****************************************************************************/

void Timer_reset(TIMER_ID ID) {
	switch (ID) {
	case TIMER0:
		TCNT0 = 0;
		break;

	case TIMER1:
		TCNT1 = 0;
		break;

	case TIMER2:
		TCNT2 = 0;
		break;

	}
}
