 /******************************************************************************
 *
 * Module: TIMER
 *
 * File Name: Timer.H
 *
 * Description: Header file for the Timer driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/

#ifndef TIMER_H_
#define TIMER_H_

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#include "std_types.h"
#include "common_macros.h"
#include "gpio.h"

/*******************************************************************************
 *                               Types Declaration                             *
 *******************************************************************************/

typedef enum {
NO_CLOCK,NO_PRESCALAR,CLK_8,CLK_64,CLK_256,CLK_1024
}TIMER_CLOCK;

typedef enum {
TIMER0,TIMER1,TIMER2
}TIMER_ID;

typedef enum {
OVERFLOW,COMPARE
}TIMER_MODE;

typedef struct{
TIMER_CLOCK clock;
TIMER_ID ID;
TIMER_MODE mode;
uint16 Compare_value;

}Timer_ConfigType;

Timer_ConfigType Configurations;

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

/*	Function description :
 *
 * 	Function that initializes the the timer module.
 *
 * 	A structure containing the timer static configurations must be passed to the function by address.
 *
 * */
void Timer_init(const Timer_ConfigType *Configurations);

/*	Function description :
 *
 * 	A Function that sets the call back to the chosen timer.
 *
 * 	Timer ID and a function must be passed to the function.
 *
 * */

void Timer_setCallBack(void(*a_ptr)(void),TIMER_ID ID);

/*	Function description :
 *
 *	A function that pauses the clock of the Timer module
 *
 *	Timer ID must be passed to the function
 *
 * */

void Timer_pause(TIMER_ID ID);

/*	Function description :
 *
 *	A function that resumes the clock of the Timer module
 *
 *	Timer ID must be passed to the function
 *
 * */

void Timer_resume(TIMER_ID ID);


/*	Function description :
 *
 *	A function that resets the Timer module
 *
 *	Timer ID must be passed to the function
 *
 * */
void Timer_reset(TIMER_ID ID);

#endif /* TIMER_H_ */
