 /******************************************************************************
 *
 * Module: Buzzer
 *
 * File Name: Buzzer.h
 *
 * Description: Header file for the Buzzer driver
 *
 * Author: Omar Ashraf
 *
 *******************************************************************************/

#ifndef BUZZER_H_
#define BUZZER_H_

#include "gpio.h"
#include "common_macros.h"
#include "std_types.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#define BUZZER_PORT PORTA_ID

#define BUZZER_PIN1 PIN0_ID

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*  Function description :
 *
 * 	A function that initializes the Buzzer .
 *
 * */

void Buzzer_init(void);

/*  Function description :
 *
 * 	A function that turns on the Buzzer .
 *
 * */

void Buzzer_on(void);

/*  Function description :
 *
 * 	A function that Turns off the Buzzer .
 *
 * */

void Buzzer_off(void);

#endif /* BUZZER_H_ */
