/******************************************************************************
 *
 * Module: CONTROL MCU
 *
 * File Name: main.c
 *
 * Description: Source file for the CONTROL-MCU driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/



#include "main.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/*******************************************************************************
 * 								GLOBAL VARIABLES							   *
 *******************************************************************************/

uint8 i;
uint8 StoredPassword[PASS_LENGTH];
uint8 ComparedPassword[PASS_LENGTH];

uint8 match = MATCHING;
uint8 Status = 0;
uint8 Tries = 0;
uint8 operation = 0;

uint8 counter = 0;

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/

/*	A function that is used to store the received password from the other MCU in the external EEPROM	*/

void StoreRecievedPassword(void) {
	UART_receiveString(StoredPassword);
	for (int j = 0; j < PASS_LENGTH - 2; j++)
		EEPROM_writeByte(PASS_ADDRESS + j, StoredPassword[j]);
}

/*	Call back function for the timer containing a counter that increments with every interrupt	*/

void TIMER1_counter(void) {
	counter++;
}

/*	Function that compares the entered password with the stored one
 *
 * 	If the passwords match then the operation will be executed
 *
 * 	If passwords do not match , the user have 3 tries to enter the password if he enters the password
 * 	wrong in all 3 tries a buzzer will turn on for 60 secs*/

void ComparePassword(void) {

	//Receive the entered password to be compared
	for (i = 0; i < PASS_LENGTH - 2; i++) {
		ComparedPassword[i] = 0;
	}
	_delay_ms(100);
	UART_receiveString(ComparedPassword);
	_delay_ms(100);

	//If they match set the status to Pass ,else set the status to fail
	for (i = 0; i < PASS_LENGTH - 2; i++) {
		if (ComparedPassword[i] == StoredPassword[i]) {
			Tries=0;
			match = MATCHING;
			Status = PASS;
		} else {
			match = NOT_MATCHING;
			Status = FAIL;
			break;
		}
	}

	if (match == MATCHING) {
		Tries = 0;
		Status = PASS;
	} else {
		Status = FAIL;
	}
	UART_sendByte(Status);
	Tries = 0;

	/*	If the password does not match the stored one increment number of tries by one and receive another password
	 * 	to be compared
	 *
	 *	If the user enters the password wrong 3 times it will display a buzzer will turn on
	 *	that lasts for 60 secs */

	while (Status == FAIL) {
		Tries++;
		if (Tries == MAX_TRIES) {
			counter = 0;
			Timer_resume(TIMER1);
			while (counter < 20) {
				Buzzer_on();
			}
			Buzzer_off();
			Timer_pause(TIMER1);
			counter = 0;
			Tries = 0;
			Status = 0;
			break;
		}
		for (i = 0; i < PASS_LENGTH - 2; i++) {
			ComparedPassword[i] = 0;
		}
		UART_receiveString(ComparedPassword);
		for (i = 0; i < PASS_LENGTH - 2; i++) {
			if (*(ComparedPassword + i) == *(StoredPassword + i)) {
				match = MATCHING;
				Status = PASS;
			} else {
				match = NOT_MATCHING;
				Status = FAIL;
				break;
			}
		}
		if (match == MATCHING) {
			Tries = 0;
			Status = PASS;
		} else {
			Status = FAIL;
		}
		UART_sendByte(Status);

	}

}
int main() {
	//Enable the global interrupt
	SREG = (1 << 7);

	//Initialize the I2C module and setting its static configurations (by using structure)
	TWI_CONFIGURATIONS twi_configs = { PRESCALAR_1, 400000 };
	TWI_init(&twi_configs);

	//Initialize the UART module and setting its static configurations (by using structure)
	UART_CONFIGURATION uart_config = { UART_BAUDRATE, ONE_BIT, DISABLED,
			EIGHT_BITS };

	//Initialize the timer module and setting its static configurations (by using structure)
	//Setting the callback function of the timer module
	//Timer is set to compare value with an interrupt that occurs every 3 secs

	Timer_ConfigType Timer_configs = { CLK_1024, TIMER1, COMPARE, 23437 };

	//Initialize the UART module and setting its static configurations (by using structure)

	UART_init(&uart_config);
	Timer_setCallBack(TIMER1_counter, TIMER1);
	Timer_pause(TIMER1);
	Timer_init(&Timer_configs);

	//Initialize the buzzer module
	Buzzer_init();

	//Initialize the DC motor
	DcMotor_Init();

	//Store the password for the first time when opening the MCU
	StoreRecievedPassword();

	for (;;) {

		// Receive the operation chosen by the user to be executed
		operation = UART_recieveByte();
		while (operation != '+' && operation != '-') {
			operation = UART_recieveByte();
		}

		/*-------------------------operation '+' (OPEN THE DOOR)---------------------*/
		if (operation == '+') {

			/*	Compare the entered password with the stored password before executing any operation	*/
			ComparePassword();

			/*	If the password matches The door will be opening (rotate CW) for 15 secs
			 * 	then it will be open (hold) for 3 secs
			 * 	then it will be closing (rotate A-CW) for another 15 secs
			 */

			/*	If the password does not match and it is entered for more than 3 times
			 * 	a buzzer will turn on for 60 secs
			 *
			 * */

			if (Status == PASS) {
				Timer_resume(TIMER1);
				counter = 0;
				while (counter < 5) {
					DcMotor_Rotate(CLOCKWISE);

				}
				counter = 0;
				while (counter < 1) {
					DcMotor_Rotate(0);
				}
				counter = 0;
				while (counter < 5) {
					DcMotor_Rotate(ANTICLOCKWISE);
				}
				counter = 0;
				DcMotor_Rotate(0);
				Timer_pause(TIMER1);
			}
		}
		/*-------------------------operation '-' (Change the password)---------------------*/

		if (operation == '-') {

			/*	Compare the entered password with the stored password before executing any operation	*/
			ComparePassword();

		/*	If passwords match , the user is allowed to change the current stored password	*/
			if (Status == PASS) {
				StoreRecievedPassword();
			}

		}
	}
}

