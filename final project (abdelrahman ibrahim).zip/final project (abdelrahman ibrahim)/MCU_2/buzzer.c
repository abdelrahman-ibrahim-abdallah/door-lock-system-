 /******************************************************************************
 *
 * Module: Buzzer
 *
 * File Name: Buzzer.c
 *
 * Description: Source file for the Buzzer driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/

#include "Buzzer.h"

/*
 * Function description: Initialize the driver of the buzzer by setting up the pins used by the module
 * 						 to output
 *
 * Inputs : Void
 *
 * return: Void
 *
 */

void Buzzer_init()
{
	GPIO_setupPinDirection(BUZZER_PORT, BUZZER_PIN1, PIN_OUTPUT);

}

/*
 * Function description: Turns on the buzzer by setting the values of the pins to high
 *
 * Inputs : Void
 *
 * return: Void
 *
 */

void Buzzer_on()
{
GPIO_writePin(BUZZER_PORT, BUZZER_PIN1, LOGIC_HIGH);
}

/*
 * Function description: Turns off the buzzer by setting the values of the pins to low
 *
 * Inputs : Void
 *
 * return: Void
 *
 */

void Buzzer_off()
{

	GPIO_writePin(BUZZER_PORT, BUZZER_PIN1, LOGIC_LOW);
}
