 /******************************************************************************
 *
 * Module: DC MOTOR
 *
 * File Name: dc_motor.C
 *
 * Description: Source file for the DC MOTOR driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/


#include "dc_motor.h"
#include "gpio.h"
#include <avr/io.h>

/*****************************************************************************
 * Function description: Function that initiates the DC motor by setting its pins
 * 						 to be output pins.
 *
 *
 * Input: void
 *
 * return: void
 ****************************************************************************/

void DcMotor_Init(void)
{
	/* Setting the pins of the DC motor :
	 *
	 *	IN1 , IN2 and EN to all be output
	 *
	 *	Setting the EN to be logic high at all times
	 *
	 * */
	GPIO_setupPinDirection(MOTOR_PORT_ID, IN1_ID , PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_PORT_ID, IN2_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_PORT_ID, EN_ID, PIN_OUTPUT);
	GPIO_writePin(MOTOR_PORT_ID, EN_ID, LOGIC_HIGH);

	/*	Setting pins of IN to 0 at start to make motor not rotate after initialization	*/
	GPIO_writePin(MOTOR_PORT_ID, IN1_ID, 0);
	GPIO_writePin(MOTOR_PORT_ID, IN2_ID, 0);

}

/*****************************************************************************
 * Function description: Function that initiates the DC motor by setting its pins
 * 						 to be output pins.
 *
 *
 * Input: State of rotation of motor required ( Clockwise or Anti-clockwise )
 *
 * return: void
 ****************************************************************************/

void DcMotor_Rotate(DcMotor_State state)
{
	switch (state)
	{

	/* If clockwise : IN1 -> LOGIC HIGH
	 * 				  IN2 -> LOGIC LOW
	 */

	case CLOCKWISE:
		GPIO_writePin(MOTOR_PORT_ID, IN1_ID, LOGIC_HIGH);
		break;

	/* If Anti-clockwise : IN1 -> LOGIC LOW
	 * 				  	   IN2 -> LOGIC HIGH
	 */

	case ANTICLOCKWISE:
		GPIO_writePin(MOTOR_PORT_ID, IN2_ID, LOGIC_HIGH);
		break;

	/*	Default case is that motor is turned off
	 * 	IN1 -> LOGIC LOW
	 * 	IN2 -> LOGIC LOW*/

	default:
		GPIO_writePin(MOTOR_PORT_ID, IN1_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PORT_ID, IN2_ID, LOGIC_LOW);
		break;
	}

}
