 /******************************************************************************
 *
 * Module: DC MOTOR
 *
 * File Name: DC_motor.H
 *
 * Description: Header file for the DC MOTOR driver
 *
 * Author: abdelrahman ibrahim
 *
 *******************************************************************************/

#ifndef DC_MOTOR_H_
#define DC_MOTOR_H_

#include "std_types.h"
#include "common_macros.h"

/*******************************************************************************
 *                               Types Declaration                             *
 *******************************************************************************/


typedef enum{
CLOCKWISE=0b01,ANTICLOCKWISE=0b10
}DcMotor_State;

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#define MAX_SPEED 100

#define MOTOR_PORT_ID PORTA_ID

#define IN1_ID PIN5_ID
#define IN2_ID PIN6_ID
#define EN_ID PIN7_ID

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*	Function description:
 *
 * 	A function that initializes the DC motor
 *
 * 	*/

void DcMotor_Init(void);

/*	Function description:
 *
 * 	A function that makes the DC motor rotate
 *
 *	The state of the rotation of the motor ( Clockwise or Anti-clockwise ) must be passed to the function
 *
 * 	*/

void DcMotor_Rotate(DcMotor_State state);


#endif /* DC_MOTOR_H_ */
