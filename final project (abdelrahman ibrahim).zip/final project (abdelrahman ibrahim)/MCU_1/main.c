

#include "main.h"
#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>
#include"uart.h"

/*******************************************************************************
 * 								GLOBAL VARIABLES							   *
 *******************************************************************************/

uint8 password[PASS_LENGTH];
uint8 password_reconfirm[PASS_LENGTH];
uint8 entered_password[PASS_LENGTH];

uint8 password_status = NOT_SET;

uint8 status = 0;
uint8 operation = 0;

uint8 password_matching_flag = 0;

uint8 i, j;
uint8 Tries = 0;
uint8 counter = 0;

/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/

/*	Function that sets up the password in case no password is set either for the first time the
 * 	MCU is started or the password is needed to be changed	*/

void SetUpPassword(void) {

	LCD_displayString("enter a password:");
	LCD_moveCursor(1, 0);
	for (i = 0; i < PASS_LENGTH - 2; i++) {

		password[i] = KEYPAD_getPressedKey();
		if(password[i]<=9)
		{
			password[i]+='0';
		}
		LCD_displayCharacter('*');
		_delay_ms(400);
	}
	LCD_clearScreen();

	// Re-enter the entered password again to be sure it is correct
	LCD_displayString("Please re-enter:");
	LCD_moveCursor(1, 0);
	for (i = 0; i < PASS_LENGTH - 2; i++) {
		password_reconfirm[i] = KEYPAD_getPressedKey();
		if (password_reconfirm[i] <= 9) {
			password_reconfirm[i] += '0';
		}
		LCD_displayCharacter('*');
		_delay_ms(400);
	}

	//If entered and re-entered passwords matches then the password is ready to be stored
	for (i = 0; i < PASS_LENGTH - 2; i++) {
		if (password[i] == password_reconfirm[i]) {
			password_matching_flag = MATCHING;
		} else {
			password_matching_flag = 0;
			break;
		}
	}
	//If they match then send the password using the UART and change the password status flag to SET
	if (password_matching_flag == MATCHING) {
		for (i = 0; i < PASS_LENGTH - 2; i++) {
			password_reconfirm[i] = 0;
		}
		LCD_clearScreen();
		password[5] = '#';
		password[6] = '\0';
		UART_sendString(password);
		password_status = SET;
	}
	//If they do not match then both passwords must be re-entered
	else {
		LCD_clearScreen();
		LCD_displayString("Password wrong");
		for (i = 0; i < PASS_LENGTH - 2; i++) {
			password[i] = 0;
			password_reconfirm[i] = 0;
			password_status = NOT_SET;
		}
	}

}

/*	Function that asks the user to enter the password to be allowed to access any of the operations
 *
 * 	User have 3 tries only if the password is not entered correctly within the tries , the MCU will display
 * 	an error message that lasts for 60 secs and block any operation to be done on the MCU
 * 	*/

void EnterPassword(void) {
	for (i = 0; i < PASS_LENGTH - 2; i++) {
		entered_password[i] = 0;
	}
	LCD_clearScreen();
	LCD_displayString("enter password");
	LCD_moveCursor(1, 0);
	_delay_ms(500);
	for (i = 0; i < PASS_LENGTH - 2; i++) {
		entered_password[i] = KEYPAD_getPressedKey();
		if (entered_password[i] <= 9) {
			entered_password[i] += '0';
		}
		LCD_displayCharacter('*');
		_delay_ms(400);
	}
	entered_password[5] = '#';
	entered_password[6] = '\0';
	_delay_ms(100);
	UART_sendString(entered_password);

	// Receive the status of the compare from the control MCU either by them matching or not matching
	status = 0;
	status = UART_recieveByte();
	while (status != PASS && status != FAIL) {
		status = UART_recieveByte();
	}

	/*	If the password does not match the stored one increment number of tries by one and display that
	 *	they do not match
	 *
	 *	If the user enters the password wrong 3 times it will display an error message on the screen
	 *	that lasts for 60 secs */

	Tries = 0;
	while ((status == FAIL)) {
		Tries++;
		if (Tries == NO_OF_TRIES) {
			Tries = 0;
			LCD_clearScreen();
			LCD_displayString("ERROR!!!!");
			counter = 0;
			Timer_resume(TIMER1);
			while (counter < 20) {

			}
			Timer_pause(TIMER1);
			counter = 0;
			LCD_clearScreen();
			status = 0;
			break;
		}

		//If password was not matching , Display wrong password
		LCD_clearScreen();
		LCD_displayString("Wrong Password ");
		LCD_moveCursor(1, 0);
		for (i = 0; i < PASS_LENGTH - 2; i++) {
			entered_password[i] = KEYPAD_getPressedKey();
			if (entered_password[i] <= 9) {
				entered_password[i] += '0';
			}
			LCD_displayCharacter('*');
			_delay_ms(400);
		}
		entered_password[5] = '#';
		entered_password[6] = '\0';
		UART_sendString(entered_password);
		status = UART_recieveByte();
		while (status != PASS && status != FAIL) {
			status = UART_recieveByte();
		}
		if (status == PASS) {
			Tries = 0;
			break;
		}
	}

}

/*	Call back function for the timer containing a counter that increments with every interrupt	*/
void TIMER1_COUNTER(void) {
	counter++;

}

int main() {
	//Enable the global interrupt
	SREG |= (1 << 7);

	//Initialize the LCD driver
	LCD_init();

	//Initialize the UART module and setting its static configurations (by using structure)
	UART_CONFIGURATION uart_config = { 9600, ONE_BIT, DISABLED, EIGHT_BITS };
	UART_init(&uart_config);

	//Initialize the timer module and setting its static configurations (by using structure)
	//Setting the callback function of the timer module
	//Timer is set to compare value with an interrupt that occurs every 3 secs
	Timer_ConfigType TimerConfigs = { CLK_1024, TIMER1, COMPARE, 23437 };
	Timer_setCallBack(TIMER1_COUNTER, TIMER1);
	Timer_init(&TimerConfigs);
	Timer_pause(TIMER1);

	// Setting the password for the first time
	while (password_status == NOT_SET) {
		SetUpPassword();
	}
	password[5] = '#';
	password[6] = '\0';

	for (;;) {

		//	Displaying the main screen
		LCD_clearScreen();
		LCD_displayString("+:Open the door");
		LCD_moveCursor(1, 0);
		LCD_displayString("-:Change Password");

		//Choosing the required operation from the menu
		operation = KEYPAD_getPressedKey();

		switch (operation) {

		/*------------- operation '+' (OPEN THE DOOR)--------------------*/
		case '+':
			UART_sendByte('+');

			// Enter the password in order to open the door
			/*	If entered correctly , the door will :-
			 *
			 *	1) Be opening for 15 secs
			 *	2) Hold for 3 secs
			 *	3) Be closing for 15 secs in the opposite direction of the initial opening	*/

			EnterPassword();
			if (status == PASS) {
				LCD_clearScreen();
				LCD_displayString("DOOR IS  ");
				LCD_displayStringRowColumn(1, 0, "OPENING");
				Timer_resume(TIMER1);
				counter = 0;
				while (counter < 5) {
				}
				LCD_clearScreen();
				LCD_displayString("DOOR OPENED");
				counter = 0;
				while (counter < 1) {

				}
				LCD_clearScreen();
				LCD_displayString("DOOR IS ");
				LCD_displayStringRowColumn(1, 0, "CLOSING");
				counter = 0;
				while (counter < 5) {

				}
				counter = 0;
				LCD_clearScreen();
				Timer_pause(TIMER1);

			}
			operation=0;
			break;

			/*-------------------- operation '-'(Change the password) ---------------------*/

		case '-':
			UART_sendByte('-');

			/*	Enter the password in order to be able to change it*/
			EnterPassword();
			LCD_clearScreen();
			_delay_ms(200);
			for (i = 0; i < PASS_LENGTH - 2; i++) {
				password[i] = 0;
				password_status = NOT_SET;
			}

			// Allowing the user to change the password
			while (password_status == NOT_SET) {
				SetUpPassword();
			}
			operation=0;
			break;
		}
	}
}
