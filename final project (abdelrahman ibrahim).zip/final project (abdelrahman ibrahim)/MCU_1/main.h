#ifndef MCU1_H_
#define MCU1_H_

#include "gpio.h"
#include "common_macros.h"
#include "std_types.h"
#include "Timer.h"
#include "keypad.h"
#include "lcd.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/


#define FAIL 0x11
#define PASS 0x12

#define Password_set 0x86

#define MATCHING 7

#define READY_TO_SEND 9

#define NOT_SET 16
#define SET 17

#define UART_BAUDRATE 9600
#define PASS_LENGTH 7
#define NO_OF_TRIES 3

/*******************************************************************************
 *                              Functions Prototypes                           *
 *******************************************************************************/

/*	Function description:
 *
 * 	Function that is used to enter a password to be send to the other MCU to be compared
 * 	and receive the status of the compare either pass or fail
 *
 *
 * */

void EnterPassword(void);

/*	Function description:
 *
 *	Function that is used to set up the password for the first time while starting up the MCU
 *
 * */

void SetUpPassword(void);

/*	Function description:
 *
 *	Function that is the call back function of the timer
 *
 *	It increments a counter each time a timer interrupt occurs
 *
 * */

void TIMER1_COUNTER(void);

#endif /* MCU1_H_ */
